from django.apps import AppConfig


class ServerConfig(AppConfig):
    name = 'server'
